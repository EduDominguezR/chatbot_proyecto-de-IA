# Resumen técnico del procesamiento de datos

## 1. Descripción del dataset
`Wildstash/dental-treatment-planning-2.5k` (Hugging Face) es un conjunto de casos clínicos odontológicos **sintéticos** en inglés, publicado en formato JSONL con licencia Apache 2.0. Cada ejemplo es una conversación de tres mensajes (`system`, `user`, `assistant`). El mensaje `user` describe el caso (datos demográficos, motivo de consulta, historia, exploración, hallazgos radiográficos y antecedentes médicos) y el mensaje `assistant` contiene una valoración estructurada (diagnóstico, etiología, urgencia, plan de manejo, antibióticos, seguimiento, consejos y fuente de guía). Según su ficha, la urgencia se codifica como 0 = electivo, 1 = moderado y 2 = urgente.

## 2. Justificación de su selección
Es de acceso abierto, está orientado a triaje y diagnóstico dental, incluye una etiqueta explícita de urgencia con tres niveles y no contiene datos reales de pacientes (no hay información de salud protegida), lo que lo hace adecuado para un proyecto académico.

## 3. Estructura y características
Una columna de conversaciones (`messages`) con roles `system`, `user` y `assistant`. El prompt de sistema es una instrucción para el asistente y no forma parte de los datos clínicos. Longitud media del mensaje del usuario: 66.2 palabras (valor real calculado en la Fase 1).

## 4. Cantidad inicial de registros
**2,494** registros. Conversaciones completas duplicadas: 364. Mensajes `user` repetidos: 384.

## 5. Procedimiento de extracción
Se descartó el prompt de sistema. De `user` se retiró el prefijo `PATIENT:` para obtener la descripción original y se separaron las secciones por encabezados. Como síntomas se tomaron el motivo de consulta y la historia; la exploración y los hallazgos radiográficos se excluyeron de los síntomas porque son observaciones del clínico y el chatbot solo recibirá lo que escriba el paciente. La urgencia se leyó de la etiqueta explícita del mensaje `assistant` (primero JSON, después patrones `Urgency: n`), sin inferirla de palabras clave; las etiquetas ausentes o contradictorias se marcaron como pendientes de revisión (200 registros). Registros con mensaje `user` sin secciones reconocibles: 200.

## 6. Método de traducción
Traducción automática neuronal inglés→español con el modelo MarianMT `Helsinki-NLP/opus-mt-en-es`. Los textos se segmentaron en oraciones, se tradujeron por lotes (con caché y reintentos ante errores) y se reensamblaron. Se aplicó un control automático por oración (pérdida o adición de negaciones, cambio de cifras, longitud atípica, traducción vacía o sin traducir). Oraciones únicas traducidas: N/D; con alerta de calidad: N/D; casos con alguna alerta: N/D. Se exportó una muestra aleatoria para revisión manual (`muestra_revision_manual.csv`). Las etiquetas de urgencia no se modificaron (verificado con una aserción). No se realizó validación clínica de la traducción por un odontólogo salvo que se haya hecho con la muestra de revisión manual.

## 7. Técnicas de limpieza
Decodificación de entidades HTML y eliminación de etiquetas, normalización Unicode (NFC), minúsculas, eliminación de caracteres especiales (se conservan letras con acentos, ñ, ü, dígitos y puntuación básica), normalización de espacios y de puntuación repetida. No se eliminaron palabras vacías para conservar negaciones y términos clínicos (`no`, `sin`, `nunca`, `dolor`, `fiebre`, `inflamación`, `sangrado`); se verificó su frecuencia antes y después.

## 8. Tratamiento de datos faltantes, duplicados y conflictos
Se excluyeron los registros sin etiqueta válida, con traducción fallida, con texto vacío o incompleto (menos de 4 palabras), los duplicados exactos (texto y urgencia) y los textos idénticos con urgencias distintas. No se imputó ningún valor.

| Motivo de exclusión                                     | Registros   |
|:--------------------------------------------------------|:------------|
| Sin etiqueta de urgencia válida (pendiente de revisión) | 200         |
| Traducción fallida                                      | 0           |
| Texto vacío tras la limpieza                            | 0           |
| Texto incompleto (< 4 palabras)                         | 0           |
| Duplicado exacto (texto + urgencia)                     | 2,259       |
| Texto idéntico con urgencias distintas (conflicto)      | 3           |

## 9. Distribución de las clases (conjunto limpio)
| Categoría   |   Casos | Porcentaje   |
|:------------|--------:|:-------------|
| Electivo    |      15 | 46.88 %      |
| Moderado    |      11 | 34.38 %      |
| Urgente     |       6 | 18.75 %      |

Razón entre la clase mayoritaria y la minoritaria: 2.5. Longitud media de los textos: 38.2 palabras.

## 10. Método de partición
División estratificada por clase y agrupada con `StratifiedGroupKFold` (semilla 42). Los textos con similitud coseno (TF-IDF, sin usar etiquetas) mayor o igual a 1.0 se agruparon (32 grupos; el mayor con 1 registros) y cada grupo se asignó a una sola partición para evitar fuga por casos clínicamente equivalentes. Resultado: entrenamiento 22, validación 5 y prueba 5 registros.

## 11. Preparación para el entrenamiento
Entrada: `texto_limpio`; salida: `urgencia` (0, 1, 2). Vectorización TF-IDF con unigramas y bigramas (`min_df=2`, `max_df=0.95`, `sublinear_tf=True`), ajustada **solo con entrenamiento**; vocabulario resultante: 241 términos. No se emplearon diagnóstico, tratamiento ni respuesta del asistente como predictores.

Como verificación de que los datos son aprendibles, se entrenaron modelos base evaluados únicamente sobre validación:

| modelo                 |   exactitud |   F1 macro |   recall Urgente |
|:-----------------------|------------:|-----------:|-----------------:|
| Logistic Regression    |         0.6 |     0.4889 |                0 |
| Linear SVM             |         0.6 |     0.4333 |                0 |
| Complement Naive Bayes |         0.6 |     0.4333 |                0 |

## 12. Tabla comparativa de registros antes y después del preprocesamiento
| Etapa                                          | Registros   |
|:-----------------------------------------------|:------------|
| Registros descargados (original)               | 2,494       |
| Con etiqueta de urgencia identificada (Fase 2) | 2,294       |
| Pendientes de revisión de urgencia (Fase 2)    | 200         |
| Traducidos por completo (Fase 3)               | N/D         |
| Traducción fallida (Fase 3)                    | N/D         |
| Al iniciar la limpieza (Fase 4)                | 2,494       |
| Registros válidos tras el preprocesamiento     | 32          |
| Conjunto de entrenamiento                      | 22          |
| Conjunto de validación                         | 5           |
| Conjunto de prueba                             | 5           |

## 13. Limitaciones
- Según la ficha del dataset: los casos son sintéticos (no reflejan pacientes reales), cubren odontología general, fueron revisados por expertos pero no probados clínicamente y pueden reflejar sesgos de generación.
- El dataset original está en inglés; la versión en español proviene de traducción automática, que puede alterar matices clínicos aunque se aplicaron controles automáticos.
- Las etiquetas de urgencia fueron asignadas durante la generación sintética, no por triaje real; las métricas obtenidas con estos datos no garantizan el rendimiento con pacientes reales.
- Los textos generados por plantillas son más homogéneos que el lenguaje coloquial de los pacientes; el modelo podría no generalizar a faltas de ortografía, regionalismos o descripciones vagas.
- Si hay desbalance entre clases, el modelo puede rendir peor en la clase minoritaria; el error más costoso es clasificar un caso urgente como electivo.
- El sistema ofrece orientación inicial y clasificación de urgencia; no sustituye el diagnóstico de un profesional odontológico.
